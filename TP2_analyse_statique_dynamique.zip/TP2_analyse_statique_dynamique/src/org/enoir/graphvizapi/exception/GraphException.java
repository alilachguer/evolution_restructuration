package org.enoir.graphvizapi.exception;

/**
 * Created by frank on 2015/2/10.
 */
public class GraphException extends GraphvizApiException {
    public GraphException(String message) {
        super(message);
    }
}
