//////////////////////////////////
/// TP1 Refactoring
/// Ali LACHGUER _ M2 AIGLE
//////////////////////////////////

le dossier "TP1_Refactoring" contient le code de la premi�re partie du tp:
- le code � refactorer par mon bin�me: Salem Mohri

le dossier "TP1_Refactoring_MS" contient le code re�u par mon bin�me (partie 2 du TP):
- le code sur lequel j'ai r�alis� les deux refactorings

le document .pdf est le document expliquant chaque partie du TP
