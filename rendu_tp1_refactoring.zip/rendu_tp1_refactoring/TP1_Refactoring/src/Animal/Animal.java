package Animal;

/* 
 * classe abstraite animal, faudra creer une nouvelle classe pour chaque type d'animal
*/
public abstract class Animal {
	Espece espece;
	String nom;
	Type type;
	String alimentation;
}
