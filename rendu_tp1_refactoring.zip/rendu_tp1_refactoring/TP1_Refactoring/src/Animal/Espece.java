package Animal;

/* Attribut de la classe Animal
 * Contient un String qui indique l'espece de l'animal*/
public class Espece {
	String espece;

	public Espece(String espece) {
		this.espece = espece;
	}
	
}
