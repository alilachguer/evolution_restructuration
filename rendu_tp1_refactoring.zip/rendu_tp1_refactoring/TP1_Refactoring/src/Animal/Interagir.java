package Animal;

public class Interagir {

	public Interagir(){
		
	}
}
