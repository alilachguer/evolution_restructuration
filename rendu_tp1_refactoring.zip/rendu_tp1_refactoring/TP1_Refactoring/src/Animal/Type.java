package Animal;

public enum Type {
	vertebre,
	insecte,
	reptile,
	mammifere,
	poisson
}
