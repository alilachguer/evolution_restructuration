package MoyenTransport;

import java.util.Date;

public class AssuranceParameter {
	public Date debut;
	public Date fin;

	public AssuranceParameter(Date debut, Date fin) {
		this.debut = debut;
		this.fin = fin;
	}
}