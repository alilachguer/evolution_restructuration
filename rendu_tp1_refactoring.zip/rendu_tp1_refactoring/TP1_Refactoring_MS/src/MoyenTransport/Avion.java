/**
* @author Salem Mohri
* 
*/ 
package MoyenTransport;

public class Avion extends MoyenTransport{
	
public Avion(){
	}
	
	public Avion (Categorie categorie, String marque){
		this.categorie = categorie;
		this.marque = marque;
	}
	

}
