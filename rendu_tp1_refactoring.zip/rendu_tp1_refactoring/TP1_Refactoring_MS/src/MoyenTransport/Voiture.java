/**
* @author Salem Mohri
* 
*/ 
package MoyenTransport;

public class Voiture extends MoyenTransport{
	
	public Voiture(){
	}
	
	public Voiture (Categorie categorie, String marque){
		this.categorie = categorie;
		this.marque = marque;
		
	}

}
