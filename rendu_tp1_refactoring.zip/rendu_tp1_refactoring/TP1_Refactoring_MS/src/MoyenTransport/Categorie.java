/**
* @author Salem Mohri
* 
*/ 
package MoyenTransport;

public class Categorie {
	String categorie;
	
	public Categorie(String categorie){
		this.categorie = categorie;
	}

	public String getCategorie() {
		return categorie;
	}

	public void setCategorie(String categorie) {
		this.categorie = categorie;
	}
	
	

}
